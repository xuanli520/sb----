package com.novel.author.util;
import com.novel.author.util.SensitiveWordUtil;
import java.util.Arrays;
import java.util.HashSet;
import java.util.Set;

public class SensitiveWordUtil {

    private static final Set<String> SENSITIVE_WORDS = new HashSet<>(Arrays.asList(
            "暴力", "色情", "赌博", "毒品", "枪支",
            "杀人", "诈骗", "赌博网站", "翻墙",
            "代考", "作弊器", "假币", "传销"
    ));

    public static String check(String text) {
        if (text == null || text.isEmpty()) {
            return null;
        }
        for (String word : SENSITIVE_WORDS) {
            if (text.contains(word)) {
                return "包含敏感词：" + word;
            }
        }
        return null;
    }
}