package com.novel.author.service;

import com.novel.author.entity.*;
import com.novel.author.repository.*;
import com.novel.author.util.SensitiveWordUtil;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.*;
import java.util.stream.Collectors;

@Service
public class AuthorService {

    @Autowired
    private NovelRepository novelRepository;
    @Autowired
    private ChapterRepository chapterRepository;
    @Autowired
    private CommentRepository commentRepository;
    @Autowired
    private BookshelfRepository bookshelfRepository;

    // ===== 小说相关 =====

    public List<Novel> getMyNovels(Long authorId) {
        return novelRepository.findByAuthorId(authorId);
    }

    public Novel createNovel(Novel novel, Long authorId) {
        novel.setAuthorId(authorId);
        novel.setStatus("serializing");
        novel.setShelfStatus("draft");
        return novelRepository.save(novel);
    }

    public Novel updateNovel(Long novelId, Novel novel) {
        Novel exist = novelRepository.findById(novelId)
                .orElseThrow(() -> new RuntimeException("小说不存在"));
        exist.setTitle(novel.getTitle());
        exist.setCategory(novel.getCategory());
        exist.setDescription(novel.getDescription());
        return novelRepository.save(exist);
    }

    public Novel applyShelf(Long novelId) {
        Novel novel = novelRepository.findById(novelId)
                .orElseThrow(() -> new RuntimeException("小说不存在"));

        List<Chapter> chapters = chapterRepository.findByNovelIdOrderByChapterNoAsc(novelId);
        boolean hasPublished = chapters.stream().anyMatch(c -> "published".equals(c.getStatus()));
        if (!hasPublished) {
            throw new RuntimeException("至少需要发布一个章节才能申请上架");
        }

        for (Chapter chapter : chapters) {
            if ("published".equals(chapter.getStatus())) {
                String result = SensitiveWordUtil.check(chapter.getContent());
                if (result != null) {
                    throw new RuntimeException("章节《" + chapter.getTitle() + "》" + result);
                }
            }
        }

        novel.setShelfStatus("published");
        return novelRepository.save(novel);
    }

    // ===== 章节相关 =====

    public List<Chapter> getChapters(Long novelId) {
        return chapterRepository.findByNovelIdOrderByChapterNoAsc(novelId);
    }

    public Chapter createChapter(Long novelId, Chapter chapter) {
        chapter.setNovelId(novelId);
        if (chapter.getStatus() == null) {
            chapter.setStatus("draft");
        }
        List<Chapter> existing = chapterRepository.findByNovelIdOrderByChapterNoAsc(novelId);
        if (existing.isEmpty()) {
            chapter.setChapterNo(1);
        } else {
            chapter.setChapterNo(existing.get(existing.size() - 1).getChapterNo() + 1);
        }
        return chapterRepository.save(chapter);
    }

    public Chapter updateChapter(Long chapterId, Chapter chapter) {
        Chapter exist = chapterRepository.findById(chapterId)
                .orElseThrow(() -> new RuntimeException("章节不存在"));
        exist.setTitle(chapter.getTitle());
        exist.setContent(chapter.getContent());
        exist.setStatus(chapter.getStatus());
        return chapterRepository.save(exist);
    }

    public void deleteChapter(Long chapterId) {
        chapterRepository.deleteById(chapterId);
    }

    // ===== 评论相关 =====

    public List<Map<String, Object>> getMyComments(Long authorId) {
        List<Novel> myNovels = novelRepository.findByAuthorId(authorId);
        List<Long> novelIds = myNovels.stream().map(Novel::getId).collect(Collectors.toList());

        if (novelIds.isEmpty()) return new ArrayList<>();

        List<Comment> comments = commentRepository.findByNovelIdIn(novelIds);
        return comments.stream().map(c -> {
            Map<String, Object> map = new HashMap<>();
            map.put("id", c.getId());
            map.put("content", c.getContent());
            map.put("novelId", c.getNovelId());
            map.put("chapterId", c.getChapterId());
            map.put("createTime", c.getCreateTime());
            return map;
        }).collect(Collectors.toList());
    }

    public void deleteComment(Long commentId) {
        commentRepository.deleteById(commentId);
    }

    // ===== 数据看板 =====

    public Map<String, Object> getDashboard(Long authorId) {
        List<Novel> myNovels = novelRepository.findByAuthorId(authorId);
        List<Long> novelIds = myNovels.stream().map(Novel::getId).collect(Collectors.toList());

        Map<String, Object> dashboard = new HashMap<>();
        dashboard.put("novelCount", myNovels.size());

        long chapterCount = novelIds.isEmpty() ? 0 : chapterRepository.countByNovelIdIn(novelIds);
        dashboard.put("chapterCount", chapterCount);

        long commentCount = novelIds.isEmpty() ? 0 : commentRepository.countByNovelIdIn(novelIds);
        dashboard.put("commentCount", commentCount);

        long favCount = 0;
        for (Novel novel : myNovels) {
            favCount += bookshelfRepository.countByNovelId(novel.getId());
        }
        dashboard.put("favCount", favCount);

        return dashboard;
    }
}