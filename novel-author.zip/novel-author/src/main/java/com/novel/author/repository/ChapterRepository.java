package com.novel.author.repository;

import com.novel.author.entity.Chapter;
import org.springframework.data.jpa.repository.JpaRepository;
import java.util.List;

public interface ChapterRepository extends JpaRepository<Chapter, Long> {
    List<Chapter> findByNovelIdOrderByChapterNoAsc(Long novelId);
    long countByNovelIdIn(List<Long> novelIds);
}