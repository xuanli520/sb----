package com.novel.author.repository;

import com.novel.author.entity.Comment;
import org.springframework.data.jpa.repository.JpaRepository;
import java.util.List;

public interface CommentRepository extends JpaRepository<Comment, Long> {
    List<Comment> findByNovelIdIn(List<Long> novelIds);
    long countByNovelIdIn(List<Long> novelIds);
}