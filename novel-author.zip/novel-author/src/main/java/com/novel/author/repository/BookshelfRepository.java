package com.novel.author.repository;

import com.novel.author.entity.Bookshelf;
import org.springframework.data.jpa.repository.JpaRepository;

public interface BookshelfRepository extends JpaRepository<Bookshelf, Long> {
    long countByNovelId(Long novelId);
}