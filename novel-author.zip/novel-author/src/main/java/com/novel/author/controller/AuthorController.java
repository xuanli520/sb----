package com.novel.author.controller;

import com.novel.author.entity.Chapter;
import com.novel.author.entity.Novel;
import com.novel.author.service.AuthorService;
import com.novel.author.util.Result;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/api/author")
public class AuthorController {

    @Autowired
    private AuthorService authorService;

    // 临时方案：从请求头获取用户ID（后续换成JWT）
    private Long getCurrentUserId() {
        // TODO: 从JWT中获取，现在先写死为1（你的测试账号ID）
        return 1L;
    }

    // ========== 小说管理 ==========

    @GetMapping("/novels")
    public Result<List<Novel>> getMyNovels() {
        return Result.success(authorService.getMyNovels(getCurrentUserId()));
    }

    @PostMapping("/novels")
    public Result<Novel> createNovel(@RequestBody Novel novel) {
        return Result.success("创建成功", authorService.createNovel(novel, getCurrentUserId()));
    }

    @PutMapping("/novels/{id}")
    public Result<Novel> updateNovel(@PathVariable Long id, @RequestBody Novel novel) {
        return Result.success("修改成功", authorService.updateNovel(id, novel));
    }

    @PostMapping("/novels/{id}/apply")
    public Result<Novel> applyShelf(@PathVariable Long id) {
        return Result.success("上架申请已通过", authorService.applyShelf(id));
    }

    // ========== 章节管理 ==========

    @GetMapping("/novels/{novelId}/chapters")
    public Result<List<Chapter>> getChapters(@PathVariable Long novelId) {
        return Result.success(authorService.getChapters(novelId));
    }

    @PostMapping("/novels/{novelId}/chapters")
    public Result<Chapter> createChapter(@PathVariable Long novelId, @RequestBody Chapter chapter) {
        return Result.success("创建成功", authorService.createChapter(novelId, chapter));
    }

    @PutMapping("/chapters/{id}")
    public Result<Chapter> updateChapter(@PathVariable Long id, @RequestBody Chapter chapter) {
        return Result.success("修改成功", authorService.updateChapter(id, chapter));
    }

    @DeleteMapping("/chapters/{id}")
    public Result<?> deleteChapter(@PathVariable Long id) {
        authorService.deleteChapter(id);
        return Result.success("删除成功", null);
    }

    // ========== 评论管理 ==========

    @GetMapping("/comments")
    public Result<List<Map<String, Object>>> getComments() {
        return Result.success(authorService.getMyComments(getCurrentUserId()));
    }

    @DeleteMapping("/comments/{id}")
    public Result<?> deleteComment(@PathVariable Long id) {
        authorService.deleteComment(id);
        return Result.success("删除成功", null);
    }

    // ========== 数据看板 ==========

    @GetMapping("/dashboard")
    public Result<Map<String, Object>> dashboard() {
        return Result.success(authorService.getDashboard(getCurrentUserId()));
    }
}