package com.novel.author.repository;

import com.novel.author.entity.Novel;
import org.springframework.data.jpa.repository.JpaRepository;
import java.util.List;

public interface NovelRepository extends JpaRepository<Novel, Long> {
    List<Novel> findByAuthorId(Long authorId);
    long countByAuthorId(Long authorId);
}