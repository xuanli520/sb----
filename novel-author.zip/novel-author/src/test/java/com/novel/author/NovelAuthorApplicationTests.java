package com.novel.author;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class NovelAuthorApplicationTests {

    @Test
    void contextLoads() {
    }

}
